// تطبيق القرآن الكريم - الملف الرئيسي
class QuranApp {
    constructor() {
        this.currentSurahId = 1;
        this.bookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
        this.settings = {
            fontSize: parseInt(localStorage.getItem('fontSize') || '24'),
            lineHeight: parseFloat(localStorage.getItem('lineHeight') || '2.2'),
            theme: localStorage.getItem('theme') || 'light',
            autoScroll: JSON.parse(localStorage.getItem('autoScroll') || 'false'),
            showAyahNumbers: JSON.parse(localStorage.getItem('showAyahNumbers') || 'true')
        };
        this.readingProgress = JSON.parse(localStorage.getItem('readingProgress') || '{}');
        
        this.init();
    }

    init() {
        this.initializeQuranData();
        this.setupEventListeners();
        this.populateJuzFilter();
        this.populateSurahs();
        this.loadPreferences();
        this.loadLastRead();
        this.updateProgressDisplay();
    }

    initializeQuranData() {
        // تحميل بيانات القرآن
        initializeQuranText();
    }

    setupEventListeners() {
        // البحث
        document.getElementById('searchSurah').addEventListener('input', (e) => {
            this.filterSurahs(e.target.value);
        });

        // تصفية حسب النوع
        document.getElementById('filterAll').addEventListener('click', () => this.filterByType('all'));
        document.getElementById('filterMakki').addEventListener('click', () => this.filterByType('مكية'));
        document.getElementById('filterMadani').addEventListener('click', () => this.filterByType('مدنية'));

        // تصفية حسب الجزء
        document.getElementById('juzFilter').addEventListener('change', (e) => {
            this.filterByJuz(e.target.value);
        });

        // التنقل
        document.getElementById('prevSurah').addEventListener('click', () => this.navigateSurah(-1));
        document.getElementById('nextSurah').addEventListener('click', () => this.navigateSurah(1));

        // العلامات المرجعية والقراءة
        document.getElementById('bookmarkBtn').addEventListener('click', () => this.toggleBookmark());
        document.getElementById('bookmarksBtn').addEventListener('click', () => this.showBookmarks());
        document.getElementById('lastReadBtn').addEventListener('click', () => this.goToLastRead());
        document.getElementById('randomSurahBtn').addEventListener('click', () => this.goToRandomSurah());

        // إعدادات الخط
        document.getElementById('fontSizeSlider').addEventListener('input', (e) => this.changeFontSize(e.target.value));
        document.getElementById('increaseFont').addEventListener('click', () => this.adjustFontSize(2));
        document.getElementById('decreaseFont').addEventListener('click', () => this.adjustFontSize(-2));

        // إعدادات تباعد الأسطر
        document.getElementById('lineHeightSlider').addEventListener('input', (e) => this.changeLineHeight(e.target.value));
        document.getElementById('increaseLineHeight').addEventListener('click', () => this.adjustLineHeight(0.1));
        document.getElementById('decreaseLineHeight').addEventListener('click', () => this.adjustLineHeight(-0.1));

        // أوضاع القراءة
        document.getElementById('lightMode').addEventListener('click', () => this.setTheme('light'));
        document.getElementById('darkMode').addEventListener('click', () => this.setTheme('dark'));
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());

        // الإعدادات الإضافية
        document.getElementById('autoScroll').addEventListener('change', (e) => this.toggleAutoScroll(e.target.checked));
        document.getElementById('showAyahNumbers').addEventListener('change', (e) => this.toggleAyahNumbers(e.target.checked));

        // أزرار إضافية
        document.getElementById('audioBtn').addEventListener('click', () => this.toggleAudio());
        document.getElementById('copyBtn').addEventListener('click', () => this.copyCurrentSurah());

        // إغلاق النوافذ المنبثقة
        document.getElementById('closeModal').addEventListener('click', () => this.closeModal());
        document.getElementById('modal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('modal')) {
                this.closeModal();
            }
        });

        // اختصارات لوحة المفاتيح
        document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
    }

    populateJuzFilter() {
        const juzFilter = document.getElementById('juzFilter');
        for (let i = 1; i <= 30; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `الجزء ${juzNames[i-1]}`;
            juzFilter.appendChild(option);
        }
    }

    populateSurahs(filteredSurahs = surahs) {
        const surahList = document.getElementById('surahList');
        surahList.innerHTML = '';
        
        if (filteredSurahs.length === 0) {
            surahList.innerHTML = '<p class="text-center text-gray-500 py-4">لم يتم العثور على نتائج</p>';
            return;
        }

        filteredSurahs.forEach(surah => {
            const surahItem = document.createElement('div');
            surahItem.className = 'surah-list-item p-4 border-b border-gray-100 cursor-pointer flex justify-between items-center';
            
            const isBookmarked = this.bookmarks.includes(surah.id);
            const readProgress = this.readingProgress[surah.id] || 0;
            
            surahItem.innerHTML = `
                <div class="flex-1">
                    <div class="flex items-center gap-2">
                        <span class="font-bold text-lg">${surah.name}</span>
                        ${isBookmarked ? '<i class="fas fa-bookmark text-red-500 text-sm"></i>' : ''}
                    </div>
                    <div class="text-sm text-gray-500 mt-1">
                        ${surah.type} - ${surah.ayahs} آيات
                        <span class="juz-indicator">ج${toArabicNumeral(surah.juz)}</span>
                    </div>
                    ${readProgress > 0 ? `
                        <div class="mt-2">
                            <div class="bg-gray-200 rounded-full h-1.5">
                                <div class="bg-emerald-500 h-1.5 rounded-full transition-all" style="width: ${readProgress}%"></div>
                            </div>
                            <span class="text-xs text-gray-400">مقروء ${Math.round(readProgress)}%</span>
                        </div>
                    ` : ''}
                </div>
                <div class="bg-emerald-100 text-emerald-800 rounded-full w-10 h-10 flex items-center justify-center text-sm font-bold">
                    ${toArabicNumeral(surah.id)}
                </div>
            `;
            
            surahItem.addEventListener('click', () => this.loadSurah(surah.id));
            surahList.appendChild(surahItem);
        });
    }

    filterSurahs(searchTerm) {
        const filtered = surahs.filter(surah => 
            surah.name.includes(searchTerm) || 
            surah.id.toString().includes(searchTerm) ||
            toArabicNumeral(surah.id).includes(searchTerm)
        );
        this.populateSurahs(filtered);
    }

    filterByType(type) {
        // تحديث أزرار التصفية
        document.querySelectorAll('[id^="filter"]').forEach(btn => {
            btn.className = btn.className.replace('bg-emerald-500 text-white', 'bg-gray-200 text-gray-700');
        });
        
        document.getElementById(`filter${type === 'all' ? 'All' : type === 'مكية' ? 'Makki' : 'Madani'}`)
                .className = document.getElementById(`filter${type === 'all' ? 'All' : type === 'مكية' ? 'Makki' : 'Madani'}`)
                .className.replace('bg-gray-200 text-gray-700', 'bg-emerald-500 text-white');

        const filtered = type === 'all' ? surahs : surahs.filter(surah => surah.type === type);
        this.populateSurahs(filtered);
    }

    filterByJuz(juzNumber) {
        if (!juzNumber) {
            this.populateSurahs();
            return;
        }
        const filtered = surahs.filter(surah => surah.juz == juzNumber);
        this.populateSurahs(filtered);
    }

    loadSurah(id) {
        this.currentSurahId = id;
        const surah = surahs.find(s => s.id === id);
        
        if (!surah) return;

        // تحديث عنوان السورة والمعلومات
        document.getElementById('surahTitle').textContent = `سورة ${surah.name}`;
        document.getElementById('surahInfo').textContent = `${surah.type} - ${surah.ayahs} آيات`;
        document.getElementById('juzInfo').textContent = `الجزء ${juzNames[surah.juz - 1]}`;
        document.getElementById('pageInfo').textContent = `الصفحة ${surah.page}`;
        document.getElementById('pageNumber').textContent = `صفحة ${surah.page} من 604`;

        // إخفاء البسملة لسورة التوبة
        document.getElementById('bismillahContainer').style.display = id === 9 ? 'none' : 'block';

        // تحديث مؤشر العلامة المرجعية
        const bookmarkIndicator = document.getElementById('bookmarkIndicator');
        bookmarkIndicator.style.display = this.bookmarks.includes(id) ? 'block' : 'none';

        // تحميل نص السورة
        this.loadSurahText(id);

        // تحديث أزرار التنقل
        this.updateNavigationButtons();

        // حفظ آخر قراءة
        localStorage.setItem('lastReadSurah', id);
        
        // تحديث تقدم القراءة
        this.updateReadingProgress(id);

        // التمرير إلى الأعلى
        document.querySelector('.quran-text').scrollIntoView({ behavior: 'smooth' });
    }

    loadSurahText(id) {
        const quranContent = document.getElementById('quranContent');
        quranContent.innerHTML = '<div class="loading-spinner"></div><p class="text-center text-gray-500 mt-4">جاري تحميل الآيات...</p>';

        // محاكاة تحميل تدريجي
        setTimeout(() => {
            quranContent.innerHTML = '';
            
            const verses = quranText[id] || [];
            verses.forEach((ayah, index) => {
                const ayahElement = document.createElement('div');
                ayahElement.className = 'ayah-container mb-6 p-3 rounded-lg transition-all fade-in';
                ayahElement.style.animationDelay = `${index * 0.1}s`;
                
                let ayahHTML = `<span class="ayah text-right block mb-2">${ayah}</span>`;
                
                if (this.settings.showAyahNumbers) {
                    ayahHTML += `<span class="ayah-number">${toArabicNumeral(index + 1)}</span>`;
                }
                
                ayahElement.innerHTML = ayahHTML;
                
                // إضافة مستمع للنقر على الآية
                ayahElement.addEventListener('click', () => this.selectAyah(ayahElement, index + 1));
                
                quranContent.appendChild(ayahElement);
            });

            // تطبيق الإعدادات الحالية
            this.applyCurrentSettings();
        }, 500);
    }

    selectAyah(element, ayahNumber) {
        // إزالة التحديد من الآيات الأخرى
        document.querySelectorAll('.ayah-container.selected').forEach(el => {
            el.classList.remove('selected');
        });
        
        // تحديد الآية الحالية
        element.classList.add('selected');
        element.style.backgroundColor = 'rgba(58, 123, 213, 0.1)';
        
        // يمكن إضافة المزيد من الوظائف مثل التشغيل الصوتي للآية المحددة
        console.log(`تم تحديد الآية رقم ${ayahNumber} من سورة ${surahs.find(s => s.id === this.currentSurahId)?.name}`);
    }

    navigateSurah(direction) {
        const newId = this.currentSurahId + direction;
        if (newId >= 1 && newId <= surahs.length) {
            this.loadSurah(newId);
        }
    }

    updateNavigationButtons() {
        const prevBtn = document.getElementById('prevSurah');
        const nextBtn = document.getElementById('nextSurah');
        
        prevBtn.disabled = this.currentSurahId === 1;
        nextBtn.disabled = this.currentSurahId === surahs.length;
        
        prevBtn.style.opacity = prevBtn.disabled ? '0.5' : '1';
        nextBtn.style.opacity = nextBtn.disabled ? '0.5' : '1';
        
        // تحديث نص الأزرار
        if (this.currentSurahId > 1) {
            const prevSurah = surahs.find(s => s.id === this.currentSurahId - 1);
            prevBtn.querySelector('span').textContent = `سورة ${prevSurah?.name}`;
        }
        
        if (this.currentSurahId < surahs.length) {
            const nextSurah = surahs.find(s => s.id === this.currentSurahId + 1);
            nextBtn.querySelector('span').textContent = `سورة ${nextSurah?.name}`;
        }
    }

    toggleBookmark() {
        const bookmarkIndicator = document.getElementById('bookmarkIndicator');
        const bookmarkBtn = document.getElementById('bookmarkBtn');
        
        if (this.bookmarks.includes(this.currentSurahId)) {
            // إزالة العلامة المرجعية
            this.bookmarks = this.bookmarks.filter(id => id !== this.currentSurahId);
            bookmarkIndicator.style.display = 'none';
            bookmarkBtn.innerHTML = '<i class="fas fa-bookmark text-xl"></i>';
            this.showNotification('تم إزالة العلامة المرجعية', 'info');
        } else {
            // إضافة العلامة المرجعية
            this.bookmarks.push(this.currentSurahId);
            bookmarkIndicator.style.display = 'block';
            bookmarkBtn.innerHTML = '<i class="fas fa-bookmark text-xl text-amber-300"></i>';
            this.showNotification('تم إضافة العلامة المرجعية', 'success');
        }
        
        localStorage.setItem('bookmarks', JSON.stringify(this.bookmarks));
        this.populateSurahs(); // تحديث قائمة السور لإظهار العلامات المرجعية
    }

    showBookmarks() {
        if (this.bookmarks.length === 0) {
            this.showNotification('لا توجد علامات مرجعية محفوظة', 'info');
            return;
        }

        const modalTitle = document.getElementById('modalTitle');
        const modalContent = document.getElementById('modalContent');
        
        modalTitle.textContent = 'العلامات المرجعية المحفوظة';
        modalContent.innerHTML = '';

        this.bookmarks.forEach(id => {
            const surah = surahs.find(s => s.id === id);
            if (!surah) return;

            const bookmarkItem = document.createElement('div');
            bookmarkItem.className = 'flex justify-between items-center p-4 border-b border-gray-200 hover:bg-gray-50 cursor-pointer rounded-lg transition-all';
            bookmarkItem.innerHTML = `
                <div class="flex-1">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-bookmark text-red-500"></i>
                        <span class="font-bold text-lg">سورة ${surah.name}</span>
                    </div>
                    <div class="text-sm text-gray-500 mt-1">
                        ${surah.type} - ${surah.ayahs} آيات - الجزء ${juzNames[surah.juz - 1]}
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <button class="remove-bookmark bg-red-100 text-red-600 p-2 rounded-full hover:bg-red-200 transition-all" data-id="${id}">
                        <i class="fas fa-trash text-sm"></i>
                    </button>
                    <div class="bg-emerald-100 text-emerald-800 rounded-full w-10 h-10 flex items-center justify-center font-bold">
                        ${toArabicNumeral(surah.id)}
                    </div>
                </div>
            `;

            bookmarkItem.addEventListener('click', (e) => {
                if (!e.target.closest('.remove-bookmark')) {
                    this.loadSurah(id);
                    this.closeModal();
                }
            });

            bookmarkItem.querySelector('.remove-bookmark').addEventListener('click', (e) => {
                e.stopPropagation();
                this.removeBookmark(id);
                bookmarkItem.remove();
                if (this.bookmarks.length === 0) {
                    this.closeModal();
                    this.showNotification('تم حذف جميع العلامات المرجعية', 'info');
                }
            });

            modalContent.appendChild(bookmarkItem);
        });

        this.showModal();
    }

    removeBookmark(id) {
        this.bookmarks = this.bookmarks.filter(bookmarkId => bookmarkId !== id);
        localStorage.setItem('bookmarks', JSON.stringify(this.bookmarks));
        
        // تحديث المؤشر إذا كانت السورة الحالية
        if (id === this.currentSurahId) {
            document.getElementById('bookmarkIndicator').style.display = 'none';
        }
        
        this.populateSurahs();
    }

    goToLastRead() {
        const lastReadSurah = parseInt(localStorage.getItem('lastReadSurah') || '1');
        this.loadSurah(lastReadSurah);
        this.showNotification(`انتقلت إلى آخر قراءة: سورة ${surahs.find(s => s.id === lastReadSurah)?.name}`, 'success');
    }

    goToRandomSurah() {
        const randomId = Math.floor(Math.random() * surahs.length) + 1;
        this.loadSurah(randomId);
        this.showNotification(`سورة عشوائية: ${surahs.find(s => s.id === randomId)?.name}`, 'success');
    }

    // إعدادات الخط والمظهر
    changeFontSize(size) {
        this.settings.fontSize = parseInt(size);
        document.querySelector('.quran-text').style.fontSize = `${size}px`;
        document.getElementById('fontSizeDisplay').textContent = size;
        localStorage.setItem('fontSize', size);
    }

    adjustFontSize(change) {
        const slider = document.getElementById('fontSizeSlider');
        const newValue = Math.min(Math.max(parseInt(slider.value) + change, 16), 48);
        slider.value = newValue;
        this.changeFontSize(newValue);
    }

    changeLineHeight(height) {
        this.settings.lineHeight = parseFloat(height);
        document.querySelector('.quran-text').style.lineHeight = height;
        localStorage.setItem('lineHeight', height);
    }

    adjustLineHeight(change) {
        const slider = document.getElementById('lineHeightSlider');
        const newValue = Math.min(Math.max(parseFloat(slider.value) + change, 1.5), 3);
        slider.value = newValue.toFixed(1);
        this.changeLineHeight(newValue);
    }

    setTheme(theme) {
        this.settings.theme = theme;
        
        if (theme === 'dark') {
            document.body.classList.add('dark-mode');
            document.getElementById('themeToggle').innerHTML = '<i class="fas fa-sun text-yellow-400"></i>';
        } else {
            document.body.classList.remove('dark-mode');
            document.getElementById('themeToggle').innerHTML = '<i class="fas fa-moon text-gray-700"></i>';
        }
        
        localStorage.setItem('theme', theme);
        
        // تحديث أزرار وضع القراءة
        const lightBtn = document.getElementById('lightMode');
        const darkBtn = document.getElementById('darkMode');
        
        if (theme === 'light') {
            lightBtn.className = lightBtn.className.replace('bg-amber-50 border-amber-500', 'bg-amber-100 border-amber-600');
            darkBtn.className = darkBtn.className.replace('bg-gray-600', 'bg-gray-700');
        } else {
            lightBtn.className = lightBtn.className.replace('bg-amber-100 border-amber-600', 'bg-amber-50 border-amber-500');
            darkBtn.className = darkBtn.className.replace('bg-gray-700', 'bg-gray-600');
        }
    }

    toggleTheme() {
        const newTheme = this.settings.theme === 'light' ? 'dark' : 'light';
        this.setTheme(newTheme);
    }

    toggleAutoScroll(enabled) {
        this.settings.autoScroll = enabled;
        localStorage.setItem('autoScroll', enabled);
        
        if (enabled) {
            this.startAutoScroll();
        } else {
            this.stopAutoScroll();
        }
    }

    toggleAyahNumbers(show) {
        this.settings.showAyahNumbers = show;
        localStorage.setItem('showAyahNumbers', show);
        
        // إعادة تحميل النص لتطبيق الإعداد
        this.loadSurahText(this.currentSurahId);
    }

    startAutoScroll() {
        if (this.scrollInterval) clearInterval(this.scrollInterval);
        
        this.scrollInterval = setInterval(() => {
            window.scrollBy({
                top: 1,
                behavior: 'smooth'
            });
        }, 50);
    }

    stopAutoScroll() {
        if (this.scrollInterval) {
            clearInterval(this.scrollInterval);
            this.scrollInterval = null;
        }
    }

    // وظائف إضافية
    toggleAudio() {
        // يمكن إضافة تشغيل الصوت هنا
        this.showNotification('خدمة التلاوة الصوتية قيد التطوير', 'info');
    }

    copyCurrentSurah() {
        const surah = surahs.find(s => s.id === this.currentSurahId);
        const url = `${window.location.origin}${window.location.pathname}?surah=${this.currentSurahId}`;
        
        navigator.clipboard.writeText(url).then(() => {
            this.showNotification(`تم نسخ رابط سورة ${surah?.name}`, 'success');
        }).catch(() => {
            this.showNotification('فشل في نسخ الرابط', 'error');
        });
    }

    updateReadingProgress(surahId) {
        // تحديث تقدم القراءة (يمكن تحسينه بناءً على وقت القراءة الفعلي)
        const currentProgress = this.readingProgress[surahId] || 0;
        const newProgress = Math.min(currentProgress + 10, 100);
        
        this.readingProgress[surahId] = newProgress;
        localStorage.setItem('readingProgress', JSON.stringify(this.readingProgress));
        
        this.updateProgressDisplay();
    }

    updateProgressDisplay() {
        const totalSurahs = surahs.length;
        const readSurahs = Object.keys(this.readingProgress).length;
        const overallProgress = Math.round((readSurahs / totalSurahs) * 100);
        
        const progressBar = document.getElementById('progressBar');
        const progressText = document.getElementById('progressText');
        
        if (progressBar && progressText) {
            progressBar.style.width = `${overallProgress}%`;
            progressText.textContent = `${overallProgress}%`;
        }
    }

    // إدارة النوافذ المنبثقة
    showModal() {
        document.getElementById('modal').style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    closeModal() {
        document.getElementById('modal').style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    showNotification(message, type = 'info') {
        // إنشاء إشعار مؤقت
        const notification = document.createElement('div');
        notification.className = `fixed bottom-4 right-4 p-4 rounded-lg text-white z-50 transition-all transform translate-x-full opacity-0`;
        
        switch (type) {
            case 'success':
                notification.className += ' bg-green-500';
                break;
            case 'error':
                notification.className += ' bg-red-500';
                break;
            case 'warning':
                notification.className += ' bg-yellow-500';
                break;
            default:
                notification.className += ' bg-blue-500';
        }
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        // إظهار الإشعار
        setTimeout(() => {
            notification.className = notification.className.replace('translate-x-full opacity-0', 'translate-x-0 opacity-100');
        }, 100);
        
        // إخفاء الإشعار
        setTimeout(() => {
            notification.className = notification.className.replace('translate-x-0 opacity-100', 'translate-x-full opacity-0');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    handleKeyboardShortcuts(e) {
        // اختصارات لوحة المفاتيح
        if (e.ctrlKey || e.metaKey) {
            switch (e.key) {
                case 'ArrowLeft':
                    e.preventDefault();
                    this.navigateSurah(1);
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    this.navigateSurah(-1);
                    break;
                case 'b':
                    e.preventDefault();
                    this.toggleBookmark();
                    break;
                case 'd':
                    e.preventDefault();
                    this.toggleTheme();
                    break;
            }
        }
    }

    loadPreferences() {
        // تحميل الإعدادات المحفوظة
        document.getElementById('fontSizeSlider').value = this.settings.fontSize;
        document.getElementById('lineHeightSlider').value = this.settings.lineHeight;
        document.getElementById('autoScroll').checked = this.settings.autoScroll;
        document.getElementById('showAyahNumbers').checked = this.settings.showAyahNumbers;
        
        this.setTheme(this.settings.theme);
        this.applyCurrentSettings();
    }

    applyCurrentSettings() {
        const quranText = document.querySelector('.quran-text');
        if (quranText) {
            quranText.style.fontSize = `${this.settings.fontSize}px`;
            quranText.style.lineHeight = this.settings.lineHeight;
        }
        
        document.getElementById('fontSizeDisplay').textContent = this.settings.fontSize;
        
        if (this.settings.autoScroll) {
            this.startAutoScroll();
        }
    }

    loadLastRead() {
        // تحميل آخر سورة مقروءة أو البدء بالفاتحة
        const lastReadSurah = parseInt(localStorage.getItem('lastReadSurah') || '1');
        this.loadSurah(lastReadSurah);
    }
}

// تشغيل التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.quranApp = new QuranApp();
    
    // التحقق من المعاملات في الرابط
    const urlParams = new URLSearchParams(window.location.search);
    const surahParam = urlParams.get('surah');
    
    if (surahParam) {
        const surahId = parseInt(surahParam);
        if (surahId >= 1 && surahId <= 114) {
            window.quranApp.loadSurah(surahId);
        }
    }
});